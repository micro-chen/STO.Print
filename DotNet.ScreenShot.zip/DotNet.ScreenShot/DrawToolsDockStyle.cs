﻿namespace DotNet.ScreenShot
{
    public enum DrawToolsDockStyle
    {
        None = 0,
        Top,
        BottomUp,
        Bottom
    }
}
