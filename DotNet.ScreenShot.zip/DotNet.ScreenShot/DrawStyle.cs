﻿namespace DotNet.ScreenShot
{
    public enum DrawStyle
    {
        None = 0,
        Rectangle,
        Ellipse,
        Arrow,
        Text,
        Line
    }
}
